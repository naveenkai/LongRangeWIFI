package application;

import java.io.IOException;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;




public class SceneController12 extends LoginOrSignup{
	@FXML
	private Stage stage;
		@FXML
	private Scene scene;
		@FXML
	private Parent root;
		int a;
	
		
		
		
		
public void swithToScene1(ActionEvent event) throws IOException {
	
	Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
	stage = (Stage)((Node)event.getSource()).getScene().getWindow();

	scene = new Scene(root);
	stage.setScene(scene);
	stage.show();
}






public void swithToScene2(ActionEvent event) throws IOException {

	
	if(abd==2) {
		System.out.println(abd);	
	FXMLLoader loader = new FXMLLoader(getClass().getResource("Scene2.fxml"));
	root = loader.load();
	
	SwitchFrom2to3 switchFrom2to3 =loader.getController();
	
	Random dice = new Random();
	//int Rnumber;
	//Rnumber = dice.nextInt(99);
	
	switchFrom2to3.sample();
	
	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	scene = new Scene(root);
	stage.setScene(scene);
	stage.show();
	}
	
	if(abd==1){
	 
		FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginOrSignup.fxml"));
		root = loader.load();
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		
		
	}
}







public void swithToSignup(ActionEvent event) throws IOException {
	FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginOrSignup.fxml"));
	root = loader.load();
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	scene = new Scene(root);
	stage.setScene(scene);
	stage.show();
	
}


}