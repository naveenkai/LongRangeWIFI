package application;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class SwirchFrom4to5 {
	int n=5;
	@FXML
	private Stage stage;
		@FXML
	private Scene scene;
		@FXML
	private Parent root;
	int ab;	
	@FXML
	TextField nav1;
	@FXML
	TextField nav2;
	@FXML
	TextField nav3;
	@FXML
	TextField nav21;
	@FXML
	TextField nav22;
	@FXML
	TextField nav23;
	@FXML
	TextField nav31;
	@FXML
	TextField nav32;
	@FXML
	TextField nav33;
	@FXML
	TextField nav41;
	@FXML
	TextField nav42;
	@FXML
	TextField nav43;
	@FXML
	TextField nav51;
	@FXML
	TextField nav52;
	@FXML
	TextField nav53;
	@FXML
	Label re1;
	@FXML
	Label re2;
	@FXML
	Label re3;
	@FXML
	Label re4;
	@FXML
	Label re5;
	@FXML
	Button lik1;
	@FXML
	Button lik2;
	@FXML
	Button lik3;
	@FXML
	Button lik4;
	@FXML
	Button lik5;
	
	static int  dataLimit1;
	static int  dataLimit2;
	static int  dataLimit3;
    static int  dataLimit4;
	static int  dataLimit5;


//	@FXML
//	TextField nav1;
//	@FXML
//	TextField nav1;
//	@FXML
//	TextField nav1;
	
	int n1;
	public void swithToScene5(ActionEvent event) throws IOException {
		
		Parent root = FXMLLoader.load(getClass().getResource("Scene5.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();

		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	void  Npasser(String n ) {
		n1=Integer.parseInt(n);
	
			if(n1==1) {
				re5.setVisible(false);
				re4.setVisible(false);
				re3.setVisible(false);
				re2.setVisible(false);
				nav21.setVisible(false);	
				nav22.setVisible(false);	
				nav23.setVisible(false);	
				nav31.setVisible(false);	
				nav32.setVisible(false);	
				nav33.setVisible(false);	
				nav41.setVisible(false);	
				nav42.setVisible(false);	
				nav43.setVisible(false);	
				nav51.setVisible(false);	
				nav52.setVisible(false);	
				nav53.setVisible(false);
				lik2.setVisible(false);
				lik3.setVisible(false);
				lik4.setVisible(false);
				lik5.setVisible(false);
				
			}
			
			if(n1==2) {
				re4.setVisible(false);
				re3.setVisible(false);
				re5.setVisible(false);
				nav31.setVisible(false);	
				nav32.setVisible(false);	
				nav33.setVisible(false);	
				nav41.setVisible(false);	
				nav42.setVisible(false);	
				nav43.setVisible(false);	
				nav51.setVisible(false);	
				nav52.setVisible(false);	
				nav53.setVisible(false);
				lik3.setVisible(false);
				lik4.setVisible(false);
				lik5.setVisible(false);
				
				
			}
			
			if(n1==3) {
				re4.setVisible(false);
				re5.setVisible(false);
				//re5.setVisible(false);
				nav41.setVisible(false);	
				nav42.setVisible(false);	
				nav43.setVisible(false);	
				nav51.setVisible(false);	
				nav52.setVisible(false);	
				nav53.setVisible(false);
				lik4.setVisible(false);
				lik5.setVisible(false);
				
				
				
			}
			
			
			if(n1==4) {
				re5.setVisible(false);
				nav51.setVisible(false);	
				nav52.setVisible(false);	
				nav53.setVisible(false);
				lik5.setVisible(false);
				
				}
	}
	
	
	
	
	
	void setToTrue() {
		re5.setVisible(true);
		re4.setVisible(true);
		re3.setVisible(true);
		re2.setVisible(true);
		re1.setVisible(true);
		nav1.setVisible(true);	
		nav2.setVisible(true);	
		nav3.setVisible(true);	
		nav21.setVisible(true);	
		nav22.setVisible(true);	
		nav23.setVisible(true);	
		nav31.setVisible(true);	
		nav32.setVisible(true);	
		nav33.setVisible(true);	
		nav41.setVisible(true);	
		nav42.setVisible(true);	
		nav43.setVisible(true);	
		nav51.setVisible(true);	
		nav52.setVisible(true);	
		nav53.setVisible(true);	
		nav1.setText("192.168.1.33" );
		nav21.setText("192.168.1.45" );
		nav31.setText("192.168.1.65" );
		nav41.setText("192.168.1.37" );
		nav51.setText("192.168.1.69" );
		nav1.setEditable(false);
		nav21.setEditable(false);
		nav31.setEditable(false);
		nav41.setEditable(false);
		nav51.setEditable(false);
		lik1.setVisible(true);
		lik2.setVisible(true);
		lik3.setVisible(true);
		lik4.setVisible(true);
		lik5.setVisible(true);
		//lik1.setVisible(true);
		
		
	}
	
	
	
	
	
	
	
	
	public void DataLimitPasser(String dl11,String dl22,String dl33,String dl44,String dl55) {
		
		
		dataLimit1=Integer.parseInt(dl11);
		dataLimit2=Integer.parseInt(dl22);
		dataLimit3=Integer.parseInt(dl33);
		dataLimit4=Integer.parseInt(dl44);
		dataLimit5=Integer.parseInt(dl55);

		
	}


	
	
	
	
	
public void runthread1()
{
	Thread t=new Thread(new Runnable() {
		public void run() 
		{
		for(int i=0;i<10;i++)
			System.out.println(i);
			test1();
			test2();
			test3();
			test4();
			test5();
			
		}
	});

t.start();	
	
	
	
}

public void test1() {
	Timer timer=new Timer();
	TimerTask timerTask = new TimerTask() {
		
		@Override
		public void run() {
			Platform.runLater(new Runnable() {
				
				@Override
				public void run() {
					nav2.setText(ab +"");
					ab++;
					
					nav3.setText(ab*3 +"");
					
						}
			});	
			
		}
	};
	timer.schedule(timerTask, 0, 1000);
}






public void test2() {
	Timer timer=new Timer();
	TimerTask timerTask = new TimerTask() {
		
		@Override
		public void run() {
			Platform.runLater(new Runnable() {
				
				@Override
				public void run() {
					nav22.setText(ab +"");
					ab++;
					nav23.setText(ab*3 +"");

					}
			});
				}
	};
	timer.schedule(timerTask, 0, 1000);
}






public void test3() {
	Timer timer=new Timer();
	TimerTask timerTask = new TimerTask() {
		
		@Override
		public void run() {
			Platform.runLater(new Runnable() {
				
				@Override
				public void run() {
					nav32.setText(ab +"");
					ab++;
					nav33.setText(ab*3 +"");

				}
			});
			}
	};
	timer.schedule(timerTask, 0, 1000);
}






public void test4() {
	Timer timer=new Timer();
	TimerTask timerTask = new TimerTask() {
		
		@Override
		public void run() {
			Platform.runLater(new Runnable() {
				
				@Override
				public void run() {
			
					nav42.setText(ab +"");
					ab++;
					nav43.setText(ab*3 +"");

				}
			});		
		}
	};
	
	timer.schedule(timerTask, 0, 1000);
}






public void test5() {
	Timer timer=new Timer();
	TimerTask timerTask = new TimerTask() {
		
		@Override
		public void run() {
			Platform.runLater(new Runnable() {
				
				@Override
				public void run() {
					nav52.setText(ab +"");
					ab++;
					nav53.setText(ab*3 +"");

				}
			});

		}
	};
	timer.schedule(timerTask, 0, 1000);
}


}

class DivideIntoThreads{
	
	
	
	
	
	
	
}
