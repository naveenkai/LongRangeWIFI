package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

	

public class ReceiverScene extends SwitchFrom2to3 {

	@FXML
	private Stage stage;
		@FXML
	private Scene scene;
		@FXML
	private Parent root;

		
		
		
	public void swithToScene1ByLogin(ActionEvent event) throws IOException {
		//myIp.setText("192.168.1.99" );
		Parent root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		
		}
}
	





