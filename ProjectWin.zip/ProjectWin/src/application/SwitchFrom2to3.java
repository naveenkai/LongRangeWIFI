package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SwitchFrom2to3  {
	@FXML
	TextField myName;
	@FXML
    TextField myIp;
	@FXML
	TextField myPhNo;
	@FXML
	Label phNoError;
	@FXML
	Label validateCheckLabel;
	@FXML
	private Stage stage;
		@FXML
	private Scene scene;
		@FXML
	private Parent root;
	//	private Labeled ValidateCheckLabel;
		
		
		
public SwitchFrom2to3() {
	// TODO Auto-generated constructor stub
	//this.validateCheckLabel.setText("Incomplete fields");
	
}		
		
		
		
		public void sample() {
			
	//		myIp.setText("192.168.1.99" );
			phNoError.setVisible(false);
	
			
}
  //       @FXML
		
//		SwitchFrom2to3(){
//			myIp.setText("192.168.1.99");
//		}
//		
		
		
		
			
			public void switchToReceiver(ActionEvent event) throws IOException {
			
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ReceiverScene.fxml"));
			root = loader.load();
		
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
				}
				
		
	
			
			
			
			
		
	public void swithToScene3(ActionEvent event) throws IOException {
			
		String username = myName.getText();
		String ipNo = myIp.getText();
		String PhNo	= 	myPhNo.getText();
		
			
		if(String.valueOf(PhNo).length()==10) {
			
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Scene3.fxml"));
		root = loader.load();
		SwitchFrom3to4 switchFrom3to4 =loader.getController();
		
		switchFrom3to4.selector();
		switchFrom3to4.displayName(username,ipNo,PhNo);
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		}
		
		else {
			root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
			phNoError.setVisible(true);
		}
		}
		
}
