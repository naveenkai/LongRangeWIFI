package application;


import java.sql.*;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;




public class Main extends Application {
	
	
	@Override
	public void start(Stage stage) {
		try {
			
			Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			stage.setScene(scene);
			stage.show();
			stage.setOnCloseRequest(event -> {
				event.consume();
			
			logout(stage);});
			
		
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	public void logout(Stage primaryStage) {
		Alert alert =new Alert(AlertType.CONFIRMATION);
		alert.setTitle("logout");
		alert.setHeaderText("Do You Really Want Logout??");
		alert.setContentText("Your about to LogOut");
		
		if(alert.showAndWait().get()== ButtonType.OK) {	
		System.out.println("logged out");
		primaryStage.close();
	
		
		}
		}
	
	
	
	
	
	
	
	public static void main(String[] args) throws SQLException {
		launch(args);
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//		    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/win","root","01032003@gH");
//		    java.sql.Statement st = con.createStatement();
//		 
//		 //   String sql5="create table naveen1(name varchar(10))";
//		 //   st.execute(sql5);
//		    String sql6;
//		    sql6="insert into names values('kgf')";
//		    st.executeUpdate(sql6);
//			System.out.println("asssddd");
//			
//			
//			
//		} catch (ClassNotFoundException e) {
//
//			e.printStackTrace();
//		
//		
//		
//	}
}
}
