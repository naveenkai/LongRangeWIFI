package application;


import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.paint.Color;


public class SwitchFrom3to4 {


	int receNo;
	@FXML
	private Stage stage;
		@FXML
	private Scene scene;
		@FXML
	private Parent root;
		
	@FXML
	TextField sr1;
	@FXML
	TextField sr2;
	@FXML
	TextField sr11;
	@FXML
	TextField sr22;
	@FXML
	TextField sr3;
	@FXML
	TextField sr33;
	@FXML
	TextField sr4;
	@FXML
	TextField sr44;
	@FXML
	TextField sr5;
	@FXML
	TextField sr55;
	@FXML
	Label r1;
	@FXML
	Label r2;
	@FXML
	Label r3;
	@FXML
	Label r4;
	@FXML
	Label r5;
	@FXML
	Label h1;
	@FXML
	Label h2;
	@FXML
	Button connectBt;
	@FXML
	Button startBt;
	@FXML
	TextField labelForNo;
	@FXML
	Button NoReceiverButton;
	@FXML
	Label mb;
	
	@FXML
	Label nameLabel;
	@FXML
	Label ipNoLabel;
	@FXML
	Label phoneNoLabel;
	@FXML
	Button fy;
	
	int AllowCheck=0;
	
	public void selector() {
		mb.setVisible(false);
		sr1.setVisible(false);
		sr11.setVisible(false);
		sr2.setVisible(false);
		sr22.setVisible(false);
		sr3.setVisible(false);
		sr33.setVisible(false);
		sr4.setVisible(false);
		sr44.setVisible(false);
		sr5.setVisible(false);
		sr55.setVisible(false);
		r1.setVisible(false);
		r2.setVisible(false);
		r3.setVisible(false);
		r4.setVisible(false);
		r5.setVisible(false);
		h1.setVisible(false);
		h2.setVisible(false);
		connectBt.setVisible(false);
		startBt.setVisible(false);
		
	}
	
	
	
	public void displayName(String username,String ipNo,String PhNo) {
		nameLabel.setText(username);
		 ipNoLabel.setText(ipNo);
		phoneNoLabel.setText(PhNo);
	
	}
		
	public void displayName1(String IpNo) {
		
		ipNoLabel.setText(IpNo);
		
	}
	

	public void swithToScene4(ActionEvent event) throws IOException {
//		if(receNo==AllowCheck) {
		System.out.println("ok1");
		String dl11= sr11.getText();
		String dl22= sr22.getText();
		String dl33= sr33.getText();
		String dl44= sr44.getText();
		String dl55= sr55.getText();
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Scene4.fxml"));
		root = loader.load();
		SwirchFrom4to5 switchFrom4to5 =loader.getController();
		String n=labelForNo.getText();
		switchFrom4to5.setToTrue();
		switchFrom4to5.Npasser(n);
		
		switchFrom4to5.DataLimitPasser(dl11,dl22,dl33,dl44,dl55);	
		
		
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		}
//	else {
//			System.out.println("not allowed");
//		}
//	}
	
	
	
	
	public void showNoReceiver(ActionEvent event) throws IOException{
		
		receNo = Integer.parseInt(labelForNo.getText());
		
		if (receNo==1) {
			mb.setVisible(true);
			r1.setVisible(true);
			h1.setVisible(true);
			h2.setVisible(true);
			connectBt.setVisible(true);
			sr1.setVisible(true);
			sr11.setVisible(true);
			}
		else if (receNo==2) {
			mb.setVisible(true);
			h1.setVisible(true);
			h2.setVisible(true);
			
			r1.setVisible(true);
			r2.setVisible(true);
			
			connectBt.setVisible(true);
			
			sr1.setVisible(true);
			sr11.setVisible(true);
			sr2.setVisible(true);
			sr22.setVisible(true);
			}
		
else if (receNo==3) {
	        mb.setVisible(true);
			h1.setVisible(true);
			h2.setVisible(true);
			
			r1.setVisible(true);
			r2.setVisible(true);
			r3.setVisible(true);
			
			connectBt.setVisible(true);
			
			sr1.setVisible(true);
			sr11.setVisible(true);
			sr2.setVisible(true);
			sr22.setVisible(true);
			sr3.setVisible(true);
			sr33.setVisible(true);
			}
		
		
else if (receNo==4) {
	mb.setVisible(true);
	h1.setVisible(true);
	h2.setVisible(true);
	
	r1.setVisible(true);
	r2.setVisible(true);
	r3.setVisible(true);
	r4.setVisible(true);
	
	connectBt.setVisible(true);
	
	sr1.setVisible(true);
	sr11.setVisible(true);
	sr2.setVisible(true);
	sr22.setVisible(true);
	sr3.setVisible(true);
	sr33.setVisible(true);
	sr4.setVisible(true);
	sr44.setVisible(true);
	}
		
		
else if (receNo==5) {
	mb.setVisible(true);
	h1.setVisible(true);
	h2.setVisible(true);
	
	r1.setVisible(true);
	r2.setVisible(true);
	r3.setVisible(true);
	r4.setVisible(true);
	r5.setVisible(true);
	
	connectBt.setVisible(true);
	
	sr1.setVisible(true);
	sr11.setVisible(true);
	sr2.setVisible(true);
	sr22.setVisible(true);
	sr3.setVisible(true);
	sr33.setVisible(true);
	sr4.setVisible(true);
	sr44.setVisible(true);
	sr5.setVisible(true);
	sr55.setVisible(true);
	}
		
	}
	
	
	
	 public void subCheck(ActionEvent event) throws IOException {
	 //   int ac = allowConnection();
		 
	   // if(ac==1) 
	//	 if(receNo==AllowCheck)  {
		if(String.valueOf(sr1.getText()).length()==10) {
			r1.setText("Receiver 1 Validated ");
			AllowCheck++;		
		}
		else {
			r1.setText("Enter a Valid Number");
			r1.setTextFill(Color.RED);
			}


		if(String.valueOf(sr2.getText()).length()==10) {
			r2.setText("Receiver 2 Validated ");
			AllowCheck++;		
		}
		else {
			r2.setText("Enter a Valid Number");
			r2.setTextFill(Color.RED);
			}
		
		if(String.valueOf(sr3.getText()).length()==10) {
			r3.setText("Receiver 3 Validated ");
			AllowCheck++;		
		}
		else {
			r3.setText("Enter a Valid Number");
			r3.setTextFill(Color.RED);
			}
		
		
		if(String.valueOf(sr4.getText()).length()==10) {
			r4.setText("Receiver 1 Validated ");
			AllowCheck++;		
		}
		else {
			r4.setText("Enter a Valid Number");
			r4.setTextFill(Color.RED);
			}
		
		if(String.valueOf(sr5.getText()).length()==10) {
			r5.setText("Receiver 1 Validated ");
	
			AllowCheck++;		
		}
		else {
			r5.setText("Enter a Valid Number");
			r5.setTextFill(Color.RED);
			}
		
		int allower=allowConnection();
		//if(al)
		if(allower==1) {
			swithToScene4(event);
			startBt.setVisible(true);
		}
		 else {
		    	startBt.setVisible(false);
		    }
	    }
	   
	//}
	    
	    
	 int allowConnection() {
		 if(AllowCheck==receNo) {
			 return 1;
			 
		 }
		 else {
			 return 0;
		 }
		 
		 
	 }
}
//}


	